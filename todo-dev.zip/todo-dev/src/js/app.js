import Forms from './modules/forms.js';

window.addEventListener('DOMContentLoaded', () => {
  'use strict';

  new Forms('form', '.todo-box__container').init();
});


